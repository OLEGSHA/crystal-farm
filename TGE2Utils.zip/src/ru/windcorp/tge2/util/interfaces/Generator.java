package ru.windcorp.tge2.util.interfaces;

public interface Generator<I, O> {
	
	public O generate(I input);

}
