package ru.windcorp.tge2.util.interfaces;

public interface Supplier<T> {
	
	public T supply();

}
