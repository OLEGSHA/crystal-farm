package ru.windcorp.tge2.util.dataio;

public interface DataRW extends DataReader, DataWriter {

}
