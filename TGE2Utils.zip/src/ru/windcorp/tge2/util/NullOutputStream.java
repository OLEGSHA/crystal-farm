package ru.windcorp.tge2.util;

import java.io.IOException;
import java.io.OutputStream;

public class NullOutputStream extends OutputStream {

	@Override
	public void write(int arg0) throws IOException {
		// Do nothing
	}

}
