package ru.windcorp.tge2.util.grh;

import java.io.IOException;

public class UnknownFormatException extends IOException {

	private static final long serialVersionUID = -392487631036860672L;

	public UnknownFormatException() {
		super();
	}

	public UnknownFormatException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public UnknownFormatException(String arg0) {
		super(arg0);
	}

	public UnknownFormatException(Throwable arg0) {
		super(arg0);
	}

}
