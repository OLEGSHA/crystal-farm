package ru.windcorp.tge2.util.grh;

import java.io.IOException;

public class WritingNotSupportedException extends IOException {

	public WritingNotSupportedException() {
		super();
	}

	public WritingNotSupportedException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public WritingNotSupportedException(String arg0) {
		super(arg0);
	}

	public WritingNotSupportedException(Throwable arg0) {
		super(arg0);
	}

	private static final long serialVersionUID = -6495897293359982606L;

}
